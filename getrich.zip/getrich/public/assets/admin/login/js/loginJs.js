// JavaScript Document
$(document).ready(function(){
    $(document).keydown(function(event){
		if(event.keyCode==13){
			alert("回车")
		}
	});
});