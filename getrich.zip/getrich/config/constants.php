<?php
/**
 * 常量定义文件
 * User: ljf
 * Date: 2016/9/20
 * Time: 16:41
 */

define('WEBNAME', '致富管理后台');